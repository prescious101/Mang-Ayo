package com.example.mangayo.controller;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mangayo.R;

public class UserServiceDetails extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_service_details);
        getSupportActionBar().setTitle("SERVICE DETAILS");




    }
}
